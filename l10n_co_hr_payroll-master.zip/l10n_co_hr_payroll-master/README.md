# l10n_co_hr_payroll

Versión 1.1
- Esta versión ya contiene rodamiento, campo para la EPS, FSP, Caja de compensación y porcentaje de comisión.
- La versión ya añade automaticamente todos los códigos de horas extras.
- Ya añade los códigos de venta y el rodamiento lo trae desde el contrato.